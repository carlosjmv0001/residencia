import { NextRequest } from 'next/server'
import { POST } from '../src/app/api/auth/register/route'

describe('Registration API', () => {
  it('should register a new user', async () => {
    const mockRequestBody = {
      name: 'Test User',
      email: 'test@example.com',
      password: 'password123'
    }

    const mockRequest = new NextRequest('http://localhost:3000/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(mockRequestBody)
    })

    const response = await POST(mockRequest)
    const data = await response.json()

    expect(response.status).toBe(201)
    expect(data.user).toBeDefined()
    expect(data.user.name).toBe(mockRequestBody.name)
    expect(data.user.email).toBe(mockRequestBody.email)
    expect(data.user.password).toBeUndefined()
  })
})
