import { render, screen } from '@testing-library/react'
import SignIn from '../src/app/auth/signin/page'

jest.mock('next/navigation', () => ({
  useRouter() {
    return {
      push: jest.fn(),
    }
  },
}))

describe('SignIn', () => {
  it('renders sign-in form', () => {
    render(<SignIn />)

    expect(screen.getByLabelText('Email')).toBeInTheDocument()
    expect(screen.getByLabelText('Password')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Sign In' })).toBeInTheDocument()
  })
})
